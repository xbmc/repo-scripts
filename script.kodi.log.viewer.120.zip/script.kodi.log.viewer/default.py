import sys
import os
import xbmc
import xbmcaddon

addon = xbmcaddon.Addon( id='script.kodi.log.viewer' )
cwd = xbmc.translatePath( addon.getAddonInfo('path') ).decode("utf-8")

DEBUG = False

BASE_RESOURCE_PATH = os.path.join( cwd, 'resources', 'lib' )
sys.path.append( BASE_RESOURCE_PATH )

# Start the main gui
if ( __name__ == "__main__" ):
    import gui
    ui = gui.GUI( "script-KODI_log-main.xml" , cwd, "Default" )
    ui.doModal()
    del ui
    sys.modules.clear()
    