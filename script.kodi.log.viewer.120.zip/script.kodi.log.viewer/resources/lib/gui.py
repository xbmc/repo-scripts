#-*- coding: UTF-8 -*-
import sys
import os
import re
import shutil
import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon( id='script.kodi.log.viewer' )
ADDON_TITLE = addon.getAddonInfo( 'name' )
RUNNING = 'kodilogviewer.running'

TEXT_CONTROL = 100
TEXT_SCROLL = 101
CLOSE_BUTTON = 60
REFRESH_BUTTON = 70
LOG_BUTTON = 80
OLDLOG_BUTTON = 90

CANCEL_DIALOG = ( 9, 10, 13, 92, 216, 247, 257, 275, 61467, 61448 )
ACTION_REFRESH = ( 78, 78, 78 )
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_PAGE_UP = 5
ACTION_PAGE_DOWN = 6
ACTION_HOME = 159
ACTION_END = 160
ACTION_SCROLL = ( ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN, ACTION_HOME, ACTION_END )

DEBUG = False

class GUI( xbmcgui.WindowXMLDialog ):
    
    def __init__( self, *args, **kwargs ):
        xbmcgui.WindowXMLDialog.__init__( self )
        self.get_settings()

    def get_settings(self):
        # self.email_address = addon.getSetting('email')
        # log('settings: len(email)=%d' % len(self.email_address))
        # self.skip_oldlog = addon.getSetting('skip_oldlog') == 'true'
        # log('settings: skip_oldlog=%s' % self.skip_oldlog)
        self.MOVE = int(addon.getSetting('move'))
        self.PAGE = int(addon.getSetting('page'))
        self.WRAPPED = int(addon.getSetting('wrapped'))
        self.textBoxPosition = 0
        self.END = 0;
        return None
        

    def onInit( self ):
        self.win = xbmcgui.Window(10000)
        if( not self.win.getProperty(RUNNING) ):
            self.win.setProperty( RUNNING, 'true')
            self.reset_controls()
            self.textBox = self.getControl( TEXT_CONTROL )
            self.logViewer = LogViewer()
            self.selection = OLDLOG_BUTTON
            self.set_file_selection( LOG_BUTTON )
            self.refresh( self.selection )
            self.show_control( TEXT_CONTROL )
        
            
    def show_control( self, controlId ):
        self.getControl( TEXT_CONTROL ).setVisible( controlId == TEXT_CONTROL )
        xbmc.sleep( 5 )

    def reset_controls( self ):
        self.getControl( TEXT_CONTROL ).setText( '' )
        
    def set_file_selection( self, selection ):
        if( selection != self.selection ):
            button = self.getControl(self.selection)
            button.setLabel( label=button.getLabel(), textColor='0xFFFFFFFF' )
            self.selection = selection
            button = self.getControl(self.selection)
            button.setLabel( label=button.getLabel(), textColor='0xFF00FF00' )
        else:
            self.selection = selection
    
	
    def get_rows( self ):
        text = self.textBox.getText()
        rows =  text.count("\n")
        if( self.WRAPPED > 0 ):
            rows += rows / (100 / self.WRAPPED	)       # Add statistical wrap settings
        log( "Counted %d rows" % rows )
        rows -= 42      # Subtract last window lines (approx. 42)
        return rows
	
	
    def refresh( self, logSelection ):
        logPath = self.logViewer.get_log_path()
        if( logSelection == LOG_BUTTON ):
            path = os.path.join(logPath, 'kodi.log')
        elif( logSelection == OLDLOG_BUTTON ):
            path = os.path.join(logPath, 'kodi.old.log')
        if path:    
            self.textBox.setText(self.logViewer.get_file(path))
            xbmc.sleep(300)
            self.END = self.get_rows()
            self.textBox.scroll(self.END)
            self.textBoxPosition = self.END

    def exit_script( self ):
        self.win.clearProperty( RUNNING )
        self.close()

    def onClick( self, controlId ):
        if( controlId == CLOSE_BUTTON ):
            self.exit_script()            
        if( controlId == REFRESH_BUTTON ):
            self.refresh(self.selection)
        if( controlId == LOG_BUTTON ):
            self.set_file_selection( LOG_BUTTON )
            self.refresh(self.selection)
        if( controlId == OLDLOG_BUTTON ):
            self.set_file_selection( OLDLOG_BUTTON )
            self.refresh(self.selection)
        else:
            log( 'onClick received from control %d' % controlId )

    def onAction( self, action ):
        actionId = action.getId()
        if( actionId in CANCEL_DIALOG ):
            self.exit_script()
        elif( actionId in ACTION_REFRESH ):
            self.refresh(self.selection)
        elif( actionId in ACTION_SCROLL ):
            if( actionId == ACTION_MOVE_UP ):
                self.textBoxPosition -= self.MOVE
            elif( actionId == ACTION_MOVE_DOWN ):
                self.textBoxPosition += self.MOVE
            elif( actionId == ACTION_PAGE_UP ):
                self.textBoxPosition -= self.PAGE
            elif( actionId == ACTION_PAGE_DOWN ):
                self.textBoxPosition += self.PAGE
            elif( actionId == ACTION_HOME ):
                self.textBoxPosition = 0
            elif( actionId == ACTION_END ):
                self.textBoxPosition = self.END
            if( self.textBoxPosition < 0 ):
                self.textBoxPosition = 0
            if( self.textBoxPosition > self.END ):
                self.textBoxPosition = self.END
            self.textBox.scroll( self.textBoxPosition )
            log('Text position: %d' % self.textBoxPosition)
        else:
            log( 'actionID received %d' % actionId )

        
class LogViewer(object):
    
    def __init__(self):
        log('started')

    def get_file(self, path):
        log( 'get_file Path:%s' % path )
        if path:
            kodiFile = open( path, 'r' )
            logText = kodiFile.read()
            kodiFile.close()
        else:
            logText = ''
        return logText
        
    def get_log_path(self):
        kodi_version = xbmc.getInfoLabel( 'System.BuildVersion' )
        log( 'KODI version: #%s#' % kodi_version )
        if re.search( '^1[456789]\.', kodi_version ):
            log_path = xbmc.translatePath( 'special://logpath' )
        else:
            if xbmc.getCondVisibility( 'system.platform.osx' ):
                if xbmc.getCondVisibility( 'system.platform.atv2' ):
                    log_path = '/var/mobile/Library/Preferences'
                else:
                    log_path = os.path.join( os.path.expanduser('~'), 'Library/Logs' )
            elif xbmc.getCondVisibility( 'system.platform.ios' ):
                log_path = '/var/mobile/Library/Preferences'
            elif xbmc.getCondVisibility( 'system.platform.windows' ):
                log_path = xbmc.translatePath( 'special://home' )
            elif xbmc.getCondVisibility( 'system.platform.linux' ):
                log_path = xbmc.translatePath( 'special://home/temp' )
            else:
                # we are on an unknown OS and need to fix that here
                raise Exception( 'UNHANDLED OS' )
        log( 'Log path:%s' % log_path )
        return log_path
        
def log( msg ):
    if DEBUG:
        xbmc.log( u'%s: %s' % (ADDON_TITLE, msg) )
    
def dialog( msg ):
    Dialog = xbmcgui.Dialog()
    return Dialog.ok(ADDON_TITLE, msg)

